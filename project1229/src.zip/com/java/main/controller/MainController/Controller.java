package com.java.main.controller.MainController;

public interface Controller {

	public void execute();

}
